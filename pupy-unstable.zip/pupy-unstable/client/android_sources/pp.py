import time

def main():
    print "pp.py is not replaced with working one!"
    time.sleep(1)